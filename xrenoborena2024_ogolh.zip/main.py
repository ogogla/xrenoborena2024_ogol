import pygame
import sys
import subprocess
import json
import os
from pygame import mixer

# Инициализация pygame
pygame.init()
mixer.init()

# Настройки окна
WIDTH, HEIGHT = 1400, 793
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("BioStudy")

# Загрузка изображений
try:
    bg = pygame.image.load("background.png")
    button_map_img = pygame.image.load("button_map.png")
    next_img = pygame.image.load("next.png")
    prev_img = pygame.image.load("prev.png")
    play_img = pygame.image.load("play.png")
    all_schemes_img = pygame.image.load("all_schemes.png")
    settings_img = pygame.image.load("settings.png")
    statistics_img = pygame.image.load("statistics.png")
    bar_img = pygame.image.load("bar.png")
    medal_img = pygame.image.load("medal.png")
except pygame.error as e:
    print(f"Ошибка загрузки изображений: {e}")
    sys.exit()

# Загрузка и настройка музыки
try:
    mixer.music.load("background_music.mp3")
    mixer.music.set_volume(0.5)
except pygame.error as e:
    print(f"Ошибка загрузки музыки: {e}")

# Цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
BLUE = (50, 50, 255)
LIGHT_GRAY = (230, 230, 230)
GREEN = (50, 255, 50)
RED = (255, 50, 50)
DARK_RED = (200, 50, 50)
DARK_BLUE = (40, 40, 200)

# Шрифты
try:
    font = pygame.font.Font(None, 36)
    title_font = pygame.font.Font(None, 48)
    small_font = pygame.font.Font(None, 24)
except:
    print("Ошибка загрузки шрифтов")
    font = pygame.font.SysFont('arial', 36)
    title_font = pygame.font.SysFont('arial', 48)
    small_font = pygame.font.SysFont('arial', 24)


# Загрузка настроек и статистики
def load_settings():
    default_settings = {
        'music': True,
        'time_limit': 15,
        'questions_limit': 14,
        'volume': 0.5
    }
    try:
        with open('settings.json', 'r') as f:
            loaded = json.load(f)
            for key in default_settings:
                if key not in loaded:
                    loaded[key] = default_settings[key]
            return loaded
    except:
        return default_settings


def save_settings(settings):
    with open('settings.json', 'w') as f:
        json.dump(settings, f)


def load_stats():
    try:
        with open('stats.json', 'r') as f:
            return json.load(f)
    except:
        return {'total_games': 0, 'total_score': 0, 'best_score': 0}


def save_stats(stats):
    with open('stats.json', 'w') as f:
        json.dump(stats, f)


settings = load_settings()
stats = load_stats()

# Включение музыки согласно настройкам
if settings['music']:
    try:
        mixer.music.play(-1)
        mixer.music.set_volume(settings['volume'])
    except:
        print("Не удалось воспроизвести музыку")


# Функции для кнопок
def open_map():
    subprocess.Popen([sys.executable, "map_cell.py"])


def next_map():
    print("Следующая карта")


def prev_map():
    print("Предыдущая карта")


def play_menu():
    subprocess.Popen([sys.executable, "play_cell.py"])


def schemes():
    print("Все схемы")


def show_settings():
    global current_screen
    current_screen = "settings"


def show_statistics():
    global current_screen
    current_screen = "statistics"


def toggle_music():
    settings['music'] = not settings['music']
    save_settings(settings)
    if settings['music']:
        try:
            mixer.music.play(-1)
            mixer.music.set_volume(settings['volume'])
        except:
            print("Не удалось воспроизвести музыку")
    else:
        mixer.music.stop()


def change_volume(delta):
    settings['volume'] = max(0.0, min(1.0, settings['volume'] + delta))
    save_settings(settings)
    mixer.music.set_volume(settings['volume'])


def show_game_settings():
    global current_screen
    current_screen = "game_settings"


def show_rules():
    global current_screen
    current_screen = "rules"


def change_setting(setting, delta, min_val, max_val):
    if min_val <= settings[setting] + delta <= max_val:
        settings[setting] += delta
        save_settings(settings)


def back_to_menu():
    global current_screen
    current_screen = "main"


# Класс для кнопок
class Button:
    def __init__(self, x, y, image=None, action=None, text=None, width=None, height=None, color=None, hover_color=None,
                 text_color=BLACK):
        if image:
            self.image = image
            self.rect = self.image.get_rect(topleft=(x, y))
        else:
            self.rect = pygame.Rect(x, y, width, height)
            self.color = color
            self.hover_color = hover_color if hover_color else color
            self.text = text
            self.text_color = text_color
        self.action = action
        self.is_hovered = False

    def draw(self, screen):
        if hasattr(self, 'image'):
            screen.blit(self.image, self.rect.topleft)
        else:
            color = self.hover_color if self.is_hovered else self.color
            pygame.draw.rect(screen, color, self.rect, border_radius=10)
            if self.text:
                text_surf = font.render(self.text, True, self.text_color)
                text_rect = text_surf.get_rect(center=self.rect.center)
                screen.blit(text_surf, text_rect)

    def check_click(self, pos):
        if self.rect.collidepoint(pos) and self.action:
            self.action()

    def check_hover(self, pos):
        self.is_hovered = self.rect.collidepoint(pos)


# Создание кнопок главного меню
main_buttons = [
    Button(428, 221, button_map_img, open_map),
    Button(998.5, 370.8, next_img, next_map),
    Button(351, 370.8, prev_img, prev_map),
    Button(546, 643, play_img, play_menu),
    Button(55, 643, all_schemes_img, schemes),
    Button(1261.3, 47.4, settings_img, show_settings),
    Button(1256.9, 234.3, statistics_img, show_statistics)
]

settings_buttons = [
    Button(550, 180+70, None, show_rules, "Правила игры", 300, 50, LIGHT_GRAY, GRAY),
    Button(550, 250+70, None, toggle_music, "Музыка: Вкл" if settings['music'] else "Музыка: Выкл", 300, 50, LIGHT_GRAY,
           GRAY),
    # Громкость сдвинута вправо и выровнена
    Button(860, 320+70, None, lambda: change_volume(0.1), "+", 50, 50, LIGHT_GRAY, GRAY),
    Button(490, 320+70, None, lambda: change_volume(-0.1), "-", 50, 50, LIGHT_GRAY, GRAY),
    Button(550, 320+70, None, None, f"Громкость: {int(settings['volume'] * 100)}%", 300, 50, LIGHT_GRAY, LIGHT_GRAY),
    Button(550, 390+70, None, show_game_settings, "Настройки игры", 300, 50, LIGHT_GRAY, GRAY),
    Button(550, 460+70, None, back_to_menu, "Назад", 300, 50, RED, DARK_RED, WHITE)
]

game_settings_buttons = [
    # Настройка времени - кнопки и текст разделены
    Button(550, 259, None, lambda: change_setting('time_limit', -5, 5, 30), "-5", 80, 50, LIGHT_GRAY, GRAY),
    Button(750, 259, None, lambda: change_setting('time_limit', 5, 5, 30), "+5", 80, 50, LIGHT_GRAY, GRAY),

    # Настройка вопросов - кнопки и текст разделены
    Button(550, 359, None, lambda: change_setting('questions_limit', -1, 5, 14), "-1", 80, 50, LIGHT_GRAY, GRAY),
    Button(750, 359, None, lambda: change_setting('questions_limit', 1, 5, 14), "+1", 80, 50, LIGHT_GRAY, GRAY),

    Button(550, 450, None, back_to_menu, "Назад", 300, 50, RED, DARK_RED, WHITE)
]

# Кнопки для экрана статистики
stats_buttons = [
    Button(550, 460, None, back_to_menu, "Назад", 300, 50, BLUE, DARK_BLUE, WHITE)
]

# Кнопка "Назад" для правил
rules_back_button = Button(WIDTH // 2 - 100, HEIGHT // 2 + 180, None, back_to_menu, "Назад", 200, 50, RED, DARK_RED,
                           WHITE)

# Текущий экран
current_screen = "main"  # main, settings, game_settings, statistics, rules

# Основной цикл
clock = pygame.time.Clock()
running = True
while running:
    mouse_pos = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Левая кнопка мыши
                pos = event.pos

                if current_screen == "main":
                    for button in main_buttons:
                        button.check_click(pos)
                elif current_screen == "settings":
                    for button in settings_buttons:
                        button.check_click(pos)
                elif current_screen == "game_settings":
                    for button in game_settings_buttons:
                        button.check_click(pos)
                elif current_screen == "statistics":
                    for button in stats_buttons:
                        button.check_click(pos)
                elif current_screen == "rules":
                    rules_back_button.check_click(pos)

    # Отрисовка фона
    screen.blit(bg, (0, 0))

    # Отрисовка кнопок главного меню
    if current_screen == "main":
        for button in main_buttons:
            button.check_hover(mouse_pos)
            button.draw(screen)

        # Отрисовка шкалы опыта
        screen.blit(bar_img, (462, 47.4))
        screen.blit(medal_img, (451.8, 38.5))

        # Отрисовка прогресс-бара
        pygame.draw.rect(screen, GRAY, (515, 60, 370, 20))
        progress = stats['total_score'] / (stats['total_games'] * 14 + 1)
        pygame.draw.rect(screen, BLACK, (515, 60, 370 * progress, 20))

    # Экран правил
    elif current_screen == "rules":
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        rules_window = pygame.Surface((800, 500), pygame.SRCALPHA)
        rules_window.fill((230, 230, 230, 240))
        screen.blit(rules_window, (WIDTH // 2 - 400, HEIGHT // 2 - 250))

        title = title_font.render("Правила игры", True, BLACK)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 220))

        rules = [
            "1. Вам будут задаваться вопросы о строении клетки.",
            "2. Для ответа нужно кликнуть на соответствующий органоид.",
            "3. На каждый вопрос дается ограниченное время.",
            "4. За правильный ответ вы получаете 1 очко.",
            "5. Игра завершается после ответа на все вопросы.",
            "6. Вы можете настроить количество вопросов и время.",
            "",
            "Цель игры: набрать максимальное количество очков!"
        ]

        for i, rule in enumerate(rules):
            rule_text = small_font.render(rule, True, BLACK)
            screen.blit(rule_text, (WIDTH // 2 - 380, HEIGHT // 2 - 150 + i * 30))

        rules_back_button.check_hover(mouse_pos)
        rules_back_button.draw(screen)

    # Экран настроек игры (исправлено расположение)
    elif current_screen == "game_settings":
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        settings_window = pygame.Surface((600, 500), pygame.SRCALPHA)
        settings_window.fill((230, 230, 230, 240))
        screen.blit(settings_window, (WIDTH // 2 - 300, HEIGHT // 2 - 250))

        title = title_font.render("Настройки игры", True, BLACK)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 220))

        # Подписи для настроек (сдвинуты выше)
        time_label = font.render("Время на ответ:", True, BLACK)
        screen.blit(time_label, (WIDTH // 2 - time_label.get_width() // 2, HEIGHT // 2 - 170))

        questions_label = font.render("Количество вопросов:", True, BLACK)
        screen.blit(questions_label, (WIDTH // 2 - questions_label.get_width() // 2, HEIGHT // 2 - 70))

        for button in game_settings_buttons:
            button.check_hover(mouse_pos)
            button.draw(screen)

        # Обновляем текст текущих значений
        time_value = font.render(f"{settings['time_limit']} сек", True, BLACK)
        screen.blit(time_value, (WIDTH // 2 - time_value.get_width() // 2, HEIGHT // 2 - 120))

        questions_value = font.render(f"{settings['questions_limit']}", True, BLACK)
        screen.blit(questions_value, (WIDTH // 2 - questions_value.get_width() // 2, HEIGHT // 2 - 20))

    # Экран настроек (исправлено расположение)
    elif current_screen == "settings":
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        settings_window = pygame.Surface((600, 500), pygame.SRCALPHA)
        settings_window.fill((230, 230, 230, 240))
        screen.blit(settings_window, (WIDTH // 2 - 300, HEIGHT // 2 - 250))

        title = title_font.render("Настройки", True, BLACK)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 220))

        for button in settings_buttons:
            button.check_hover(mouse_pos)
            button.draw(screen)

        # Обновляем текст текущих значений
        music_status = "Вкл" if settings['music'] else "Выкл"
        music_text = font.render(f"Музыка: {music_status}", True, BLACK)
        volume_text = font.render(f"Громкость: {int(settings['volume'] * 100)}%", True, BLACK)

    # Экран статистики
    elif current_screen == "statistics":
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        stats_window = pygame.Surface((600, 500), pygame.SRCALPHA)
        stats_window.fill((230, 230, 230, 240))
        screen.blit(stats_window, (WIDTH // 2 - 300, HEIGHT // 2 - 250))

        title = title_font.render("Статистика", True, BLACK)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 220))

        total_games = font.render(f"Всего игр: {stats['total_games']}", True, BLACK)
        total_score = font.render(f"Всего очков: {stats['total_score']}", True, BLACK)
        best_score = font.render(f"Лучший результат: {stats['best_score']}/14", True, BLACK)

        screen.blit(total_games, (WIDTH // 2 - total_games.get_width() // 2, HEIGHT // 2 - 150))
        screen.blit(total_score, (WIDTH // 2 - total_score.get_width() // 2, HEIGHT // 2 - 100))
        screen.blit(best_score, (WIDTH // 2 - best_score.get_width() // 2, HEIGHT // 2 - 50))

        for button in stats_buttons:
            button.check_hover(mouse_pos)
            button.draw(screen)

    # Обновление экрана
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()